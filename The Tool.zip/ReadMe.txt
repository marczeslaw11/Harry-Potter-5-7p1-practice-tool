Program is simple:

In folder with saves (found in AppData) you musn't have any files/folders other than actual save file and it's copies. 

Copies must be named by the name of actual save and anything, seperate those 2 parts with space.

To switch between load and delete modes press button, that indicates what is current mode (default mode is load).

After pressing button in load mode, current save file will be replaced with the chosen one.

After pressing button in delete mode, chosen save file will be deleted.

After pressing "Change game" button, aviable games will appear in new window (note: hp7s aren't tested, please don't use it yet).

After pressing "Add save file" button, current save file will be copied and named with it's own name with added text from box above. In case box was empty, the next integer, starting with 0, will be added to the name.

HP6 edits save only at the 1st slot atm.

The "Load save pack" button uses files in "Resources" folder. Only HP5 saves aviable atm.